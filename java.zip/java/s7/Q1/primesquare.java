import prime.*;
import square.*;
import java.io.*;
import java.lang.*;
public class primesquare
{
public static void main(String args[])
{
int n;
PrimeNumbers m=new PrimeNumbers(20);
SquareSeries s=new SquareSeries(20);
}
}