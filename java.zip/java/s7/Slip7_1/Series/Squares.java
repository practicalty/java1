package Series;
public class Squares
{
	public static void squareseries(int n)
	{
		for(int i=1;i<=n;i++)
		{
			System.out.print(i*i+","); 
		}
	}	
}