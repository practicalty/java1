import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class mouse extends Applet implements MouseListener,MouseMotionListener
{ int X=0,Y=20; String msg="Mouse Events";
	public void init()
	{
	addMouseListener(this);	
		addMouseMotionListener(this);
		setBackground(Color.black);
		setForeground(Color.white);
	
	}

public void mouseEntered(MouseEvent m)
{
setBackground(Color.red);
showStatus("Mouse Entered");
repaint();	
}	
public void mouseExited(MouseEvent m)
{
setBackground(Color.black);
showStatus("Mouse Exited");
repaint();		
}
public void mousePressed(MouseEvent m)
{
X=10;
	Y=20;
msg="MATH";
setBackground(Color.cyan);

repaint();	
}
public void mouseReleased(MouseEvent m)
{
X=m.getX();
	Y=m.getY();
msg="OOSE";
setBackground(Color.orange);

repaint();	
}
public void mouseMoved(MouseEvent m)
{
	X=m.getX();
	Y=m.getY();
msg="OOSE";
setBackground(Color.green);
showStatus("Mouse Moved");
repaint();	
}
public void mouseDragged(MouseEvent m)
{
	msg="CG";
setBackground(Color.white);
showStatus("Mouse clicked"+m.getX()+" and "+m.getY() );
showStatus("Mouse dragged");
repaint();	
}
public void mouseClicked(MouseEvent m)
{
	msg="PHP";
setBackground(Color.blue);
showStatus("Mouse clicked");
repaint();
	
}
public void paint(Graphics g)
{
	g.drawString(msg,X,Y);
	
}
}

/*

 <applet code="mouse" width=500 height=500>
 
 </applet>
*/

