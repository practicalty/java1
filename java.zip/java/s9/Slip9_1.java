
Slip9_1 ,Slip19_1. Create an applet which display a message in the center of the screen. The message indicates the events taking place on the applet window. Handle events like mouse click, mouse moves, mouse dragged, mouse pressed. The message should update each time an event occurs. The message should give details of the event such as which mouse button was pressed ( hint: use repaint(), mouselistener, MouseMotionListener)

import java.awt.*;
import java.applet.*;
import javax.swing.*;
import java.awt.event.*;
/*
<applet code="MouseApplet.java" width=1500 height=800>
</applet>
   */
public class MouseApplet extends Applet
{
                JPanel p;
                JTextField t;
                String msg;
                public void init()
                {
                                t=new JTextField(20);
                                add(t);
                                addMouseListener(new MouseAdapter()
                                                                {
                                                                public void mouseClicked(MouseEvent me)
                                                                {
                                                                msg="Mouse Clicked : X = "+me.getX() + " Y = "+me.getY();
                                                                t.setText(msg);
                                                                }
                                                                });
                                addMouseMotionListener(new MouseMotionAdapter()
                                                                {
                                                                public void mouseMoved(MouseEvent me)
                                                                {
                                                                msg="Mouse Moved : X = "+me.getX() +" Y = "+me.getY();
                                                                t.setText(msg);
                                                                }
                                                                });
                }
}

